# Lótus Studio — Protótipo (Front-end + stub PHP)

Conversão do protótipo do Figma para código, conforme os prints enviados:
Home → Login (simulado) → Página logada → Modal "Agendar" (Unidade → Serviços → Pagamento → Confirmação) → POST do agendamento.

## Estrutura

```
lotus-studio/
├── index.html          → Home page (não logado)
├── dashboard.html       → Página "logada" (Seja bem-vindo, Leandro) + modais
├── css/style.css        → Todo o estilo (cores, tipografia, modais)
├── js/app.js             → Lógica do fluxo de agendamento (passo a passo)
└── api/agendamento.php   → Stub do backend (recebe o POST do agendamento)
```

## Como testar agora (sem servidor PHP)

Basta abrir `index.html` direto no navegador (duplo clique).
O botão **Login** leva para `dashboard.html`, simulando o usuário logado.

No `dashboard.html`, clique em **Agendar** para abrir o fluxo de modais:

1. **Unidade** — escolha uma das 4 unidades (clique no card).
2. **Serviços** — adicione um ou mais serviços com o botão `+`, veja o total
   atualizando no card lateral, e clique em **Continuar**.
3. **Pagamento** — escolha Pix, Crédito ou Débito.
4. **Confirmação** — confira o resumo, ajuste o nome do cliente se quiser, e
   clique em **Confirmar Agendamento**.
5. **Sucesso** — mostra o protocolo gerado.

> Como ainda não há um servidor PHP rodando, o `js/app.js` tenta o `fetch`
> em `api/agendamento.php` e, se falhar (ex.: abrindo via `file://`), usa
> automaticamente uma resposta simulada — então o fluxo completo funciona
> mesmo sem backend ativo. Quando você rodar com PHP (XAMPP, `php -S`, etc.),
> o POST real será usado automaticamente, sem precisar mudar nada no JS.

## Como testar com o PHP rodando

Dentro da pasta `lotus-studio/`:

```bash
php -S localhost:8000
```

Depois acesse `http://localhost:8000/index.html`. Agora o POST vai
de fato para `api/agendamento.php`, que já valida os campos e devolve um
protocolo — só falta você plugar o banco de dados (tem um `TODO` comentado
no arquivo indicando onde entra o `INSERT`).

## O que o POST envia

```json
{
  "nome_cliente": "Leandro",
  "unidade": "Barra da Tijuca",
  "servicos": ["Massagem Relaxante"],
  "pagamento": "Pix",
  "cupom": null,
  "total": 99.0
}
```

## Imagens

Crie uma pasta `img/` dentro de `lotus-studio/` com os seus arquivos. O
código assume a extensão **.png** — se as suas forem `.jpg`/`.webp`, basta
um find-and-replace de `.png` para a extensão certa nesses 3 arquivos:
`index.html`, `dashboard.html`, `js/app.js`.

| Arquivo (sem extensão)         | Onde é usado                                              |
|---------------------------------|------------------------------------------------------------|
| `logo`                          | Logo grande no rodapé (footer)                              |
| `logo-menor-header-a-img`       | Logo do cabeçalho (header), nas duas páginas                |
| `hero`                          | Foto grande da Home                                          |
| `card-img`                      | Ícone dos 3 cards "Nossos cuidados" na Home                  |
| `barradatijuca-img`             | Foto da unidade Barra da Tijuca (modal Unidade)               |
| `recreio-img`                   | Foto da unidade Recreio (modal Unidade)                       |
| `botafogo-img`                  | Foto da unidade Botafogo (modal Unidade)                       |
| `copacabana-img`                | Foto da unidade Copacabana (modal Unidade)                     |
| `unidade-img`                   | Ícone do card "Unidade favorita" no dashboard                  |
| `massagem-relaxante`            | Foto do serviço Massagem Relaxante (modal Serviços)             |
| `massagem-facial-img`           | Foto do serviço Massagem Facial (modal Serviços)                |
| `vacuo-terapia-img`             | Foto do serviço Vácuo terapia (modal Serviços)                  |
| `terapia-aromatica-img`         | Foto do serviço Terapia Aromática (modal Serviços)              |
| `pix-img`                       | Ícone de pagamento Pix (Crédito/Débito ficaram com ícone genérico, sem imagem própria) |

A foto da unidade escolhida também aparece automaticamente no card-resumo
do step de Serviços (lado direito), reaproveitando a mesma imagem da
unidade selecionada.

## Observações de design

- Tipografia: **Inter** (texto) e **Lora** (títulos), conforme pedido. A
  logo agora é a sua imagem real (`logo` / `logo-menor-header-a-img`), então
  não depende mais de fonte.
- Cores e imagens dos cards (unidades/serviços) substituídas pelas suas
  imagens reais (`img/...`). Veja a tabela acima para o mapeamento completo.
- O fluxo é todo orientado por um único objeto de estado (`state` em
  `js/app.js`), então adicionar um passo novo ou mudar a ordem é só
  editar as funções `renderStepX` / `bindStepX` e o `render()`.

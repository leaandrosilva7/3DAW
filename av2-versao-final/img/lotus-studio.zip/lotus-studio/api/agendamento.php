<?php
/**
 * api/agendamento.php
 * -----------------------------------------------------------
 * Endpoint provisório que recebe o POST do fluxo de agendamento
 * (front-end em js/app.js). Hoje ele apenas valida e devolve um
 * JSON de sucesso — sem salvar em banco de dados. Use como ponto
 * de partida para a sua implementação em PHP.
 *
 * Payload recebido (JSON):
 * {
 *   "nome_cliente": "Leandro",
 *   "unidade": "Barra da Tijuca",
 *   "servicos": ["Massagem Relaxante"],
 *   "pagamento": "Pix",
 *   "cupom": null,
 *   "total": 99.0
 * }
 * -----------------------------------------------------------
 */

header("Content-Type: application/json; charset=utf-8");

// Ajuste/remova em produção — útil apenas se for testar o front
// servido de uma origem diferente do PHP durante o desenvolvimento.
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "mensagem" => "Método não permitido."]);
    exit;
}

$raw  = file_get_contents("php://input");
$body = json_decode($raw, true);

if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(["success" => false, "mensagem" => "JSON inválido."]);
    exit;
}

$nomeCliente = trim($body['nome_cliente'] ?? '');
$unidade     = trim($body['unidade'] ?? '');
$servicos    = $body['servicos'] ?? [];
$pagamento   = trim($body['pagamento'] ?? '');
$cupom       = $body['cupom'] ?? null;
$total       = $body['total'] ?? 0;

// --- validação básica ---
$erros = [];
if ($nomeCliente === '')          $erros[] = "nome_cliente é obrigatório.";
if ($unidade === '')              $erros[] = "unidade é obrigatória.";
if (!is_array($servicos) || empty($servicos)) $erros[] = "servicos é obrigatório (lista não pode ser vazia).";
if ($pagamento === '')            $erros[] = "pagamento é obrigatório.";

if (!empty($erros)) {
    http_response_code(422);
    echo json_encode(["success" => false, "mensagem" => "Dados inválidos.", "erros" => $erros]);
    exit;
}

// -----------------------------------------------------------
// TODO: salvar no banco de dados (ex.: tabela `agendamentos`).
// Sugestão de estrutura:
//   id, nome_cliente, unidade, servicos (JSON ou tabela N:N),
//   pagamento, cupom, total, status, created_at
//
// Exemplo (pseudo, ajuste para seu driver de banco / PDO):
//
// $pdo->prepare("INSERT INTO agendamentos
//   (nome_cliente, unidade, servicos, pagamento, cupom, total, created_at)
//   VALUES (?, ?, ?, ?, ?, ?, NOW())")
//   ->execute([$nomeCliente, $unidade, json_encode($servicos), $pagamento, $cupom, $total]);
// -----------------------------------------------------------

$protocolo = "LTS-" . date("Ymd") . "-" . str_pad((string) random_int(0, 9999), 4, "0", STR_PAD_LEFT);

http_response_code(201);
echo json_encode([
    "success"   => true,
    "protocolo" => $protocolo,
    "mensagem"  => "Agendamento confirmado com sucesso!",
    "dados"     => [
        "nome_cliente" => $nomeCliente,
        "unidade"      => $unidade,
        "servicos"     => $servicos,
        "pagamento"    => $pagamento,
        "cupom"        => $cupom,
        "total"        => $total
    ]
]);
